<!--begin::Row-->
<div class="row">
	<div class="col-lg-4">
		<!--begin::Mixed Widget 14-->
		<div class="card card-custom card-stretch gutter-b">
			<!--begin::Header-->
			<div class="card-header border-0 pt-5">
				<h3 class="card-title font-weight-bolder">Persentase Pinjaman</h3>
			</div>
			<!--end::Header-->
			<!--begin::Body-->
			<div class="card-body d-flex flex-column">
				<div class="flex-grow-1">
					<div id="kt_mixed_widget_14_chart" style="height: 200px"></div>
				</div>
				<div class="pt-5">
					<p class="text-center font-weight-normal font-size-lg pb-7">74% pinjaman telah lunas</p>
					<a href="#" class="btn btn-success btn-shadow-hover font-weight-bolder w-100 py-3">Selengkapnya</a>
				</div>
			</div>
			<!--end::Body-->
		</div>
		<!--end::Mixed Widget 14-->
	</div>
	<div class="col-lg-8">
		<!--begin::Advance Table Widget 4-->
		<div class="card card-custom card-stretch gutter-b">
			<!--begin::Header-->
			<div class="card-header border-0 py-5">
				<h3 class="card-title align-items-start flex-column">
					<span class="card-label font-weight-bolder text-dark">Outstanding Pembiayaan</span>
				</h3>
			</div>
			<!--end::Header-->
			<!--begin::Body-->
			<div class="card-body pt-0 pb-3">
				<div class="tab-content">
					<!--begin::Table-->
					<div class="table-responsive">
						<table class="table table-head-custom table-head-bg table-borderless table-vertical-center">
							<thead>
								<tr class="text-left text-uppercase">
									<th style="min-width: 250px" class="pl-7">
										<span class="text-dark-75">peruntukan</span>
									</th>
									<th style="min-width: 100px">outstanding</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td class="pl-0 py-8">
										<div class="d-flex align-items-center">
											<div class="symbol symbol-50 symbol-light mr-4">
												<span class="symbol-label">
													<img src="assets/media/svg/avatars/modal_kerja.png" class="h-75 align-self-end" alt="" />
												</span>
											</div>
											<div>
												<a href="#" class="text-dark-75 font-weight-bolder text-hover-primary mb-1 font-size-lg">Modal Kerja</a>
											</div>
										</div>
									</td>
									<td>
										<span class="text-dark-75 font-weight-bolder d-block font-size-lg">IDR 79.127.248.143</span>
									</td>
								</tr>
								<tr>
									<td class="pl-0 py-0">
										<div class="d-flex align-items-center">
											<div class="symbol symbol-50 symbol-light mr-4">
												<span class="symbol-label">
													<img src="assets/media/svg/avatars/perumahan.png" class="h-75 align-self-end" alt="" />
												</span>
											</div>
											<div>
												<a href="#" class="text-dark-75 font-weight-bolder text-hover-primary mb-1 font-size-lg">Perumahan</a>
											</div>
										</div>
									</td>
									<td>
										<span class="text-dark-75 font-weight-bolder d-block font-size-lg">IDR 6.056.337.151</span>
									</td>
								</tr>
								<tr>
									<td class="pl-0 py-8">
										<div class="d-flex align-items-center">
											<div class="symbol symbol-50 symbol-light mr-4">
												<span class="symbol-label">
													<img src="assets/media/svg/avatars/pendidikan.png" class="h-75 align-self-end" alt="" />
												</span>
											</div>
											<div>
												<a href="#" class="text-dark-75 font-weight-bolder text-hover-primary mb-1 font-size-lg">Pendidikan</a>
											</div>
										</div>
									</td>
									<td>
										<span class="text-dark-75 font-weight-bolder d-block font-size-lg">IDR 1.314.302.348</span>
									</td>
								</tr>
								<tr>
									<td class="pl-0 py-0">
										<div class="d-flex align-items-center">
											<div class="symbol symbol-50 symbol-light mr-4">
												<span class="symbol-label">
													<img src="assets/media/svg/avatars/investasi.png" class="h-75 align-self-end" alt="" />
												</span>
											</div>
											<div>
												<a href="#" class="text-dark font-weight-bolder text-hover-primary mb-1 font-size-lg">Investasi</a>
											</div>
										</div>
									</td>
									<td class="text-left pr-0">
										<span class="text-dark-75 font-weight-bolder d-block font-size-lg">IDR 1.322.060.273</span>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<!--end::Table-->
				</div>
			</div>
			<!--end::Body-->
		</div>
		<!--end::Advance Table Widget 4-->
	</div>
</div>
<!--end::Row-->

<script src="assets/js/pages/widgets.js"></script>

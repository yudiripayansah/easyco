<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['pphoto'] = realpath(APPPATH . '../assets/media/users/');
$config['plocation'] = './assets/media/users/';

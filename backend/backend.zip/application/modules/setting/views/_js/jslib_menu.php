<script src="<?php echo base_url('assets/js/jquery.livequery.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery-ui/ui/i18n/grid.locale-en.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/jquery-grid/jquery.jqGrid.min.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/jquery.blockui.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/js/jquery-nestable/jquery.nestable.js'); ?>" type="text/javascript"></script>
  